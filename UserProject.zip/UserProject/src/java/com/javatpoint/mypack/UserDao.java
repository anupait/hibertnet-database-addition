package com.javatpoint.mypack;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

public class UserDao {

	public static int register(User u){
        int i=0;
               
	    Session sess=new Configuration().configure().buildSessionFactory().openSession();
            try {
            sess.getTransaction().begin();
            i=(Integer)sess.save(u);
            // do some work
            sess.getTransaction().commit();
            return i ;
            }
            catch (RuntimeException e) {
            sess.getTransaction().rollback();
            throw e;
           }
      
 
  }    
               
}


  
